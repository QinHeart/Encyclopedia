```
AdGuard DNS Filter

AdGuard 官方维护的广告规则，涵盖多种过滤规则

https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt
```

```
AdAway

AdAway 官方的去广告 Host 规则

https://adaway.org/hosts.txt
```

```
ADgk

适用于 AdGuard for Android 的去广告规则，去视频 APP 广告、开屏广告

https://banbendalao.coding.net/p/adgk/d/ADgk/git/raw/master/ADgk.txt
```

```
anti-AD

命中率高、兼容性强

https://anti-ad.net/easylist.txt
```

```
halflife

涵盖了 EasyList China、EasyList Lite、CJX 's Annoyance、乘风视频过滤规则，以及补充的其它规则

https://gitee.com/halflife/list/raw/master/ad.txt
```

```
EasyList

Adblock Plus 官方维护的广告规则

https://easylist-downloads.adblockplus.org/easylist.txt
```

```
EasyPrivacy

反隐私跟踪、挖矿规则

https://easylist-downloads.adblockplus.org/easyprivacy.txt
```

```
Xinggsf 乘风通用

国内网站广告过滤规则

https://gitee.com/xinggsf/Adblock-Rule/raw/master/rule.txt
```

```
Xinggsf 乘风视频

视频网站广告过滤规则

https://gitee.com/xinggsf/Adblock-Rule/raw/master/mv.txt
```

```
MalwareDomainList

恶意软件过滤规则

https://www.malwaredomainlist.com/hostslist/hosts.txt
```

```
Adblock Warning Removal List

去除禁止广告拦截提示规则

https://easylist-downloads.adblockplus.org/antiadblockfilters.txt
```

```
Fanboy's Annoyances List

去除页面弹窗广告规则

https://easylist-downloads.adblockplus.org/fanboy-annoyance.txt
```

