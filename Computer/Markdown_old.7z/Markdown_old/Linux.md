# linux入门

## GUN基础

### 认识Linux

```
Linux --> Ubuntu、Centos、Red Hat、Kail...
Debain --> Ubuntu、Kail、Grml、Tails、Purism PureOS
Fedora --> RedHat、CentOS
OpenSUSE
```

```
Linux入门不是学Linux
	1.比较Linux系统和其他系统的不同点与相同点
	2.Linux GUI --> Shell
```

### linux操作系统

```
1.linux kernel 内核
2.GUN工具（命令）
3.GUI 工具（界面
4.Application 应用
========================================
GUN's Not Unix
IT术语，它并不属于通常的英语音标--> 专业是术语
```



### 安装 wmtools(Desktop)

找出安装包位置

```
ls
tar -zxvf VM
cd VM
sudo ./vmware-install.pl
```

### 基础配置

```
注：替换阿里云镜像源 http://mirrors.aliyun.com/ubuntu/

1.安装 net-tools -->sudo apt install net-tools

2.安装 ssh --> sudo apt install ssh

3.更新服务器 --> sudo apt --upgradable
sudo apt update
sudo apt upgrade
```



### Linux内核：操作系统

```
1.硬件设备 管理使用
2.软件程序（系统）-> 操作软件
3.系统内存
4.文件管理 保存文件，删除文件，修改文件文件系统：读，写的标准

df -T  分区状态
GNU组织：Unix上具有的一些软件，Linux内核本身没有，所以GNU他们模仿Unix，为Linux写了一些必要的软件。

1.GNU核心：
原本在Unix上的一些命令和工具，被模仿（移植）到了Linux上。
供Linux使用的这套工具：coreutils coreutilities软件包
（1）用来处理文件的工具
（2）用来操作文本的工具
（3）用来管理进程的工具

2.shell提供给用户使用的软件：用户拿它来使用电脑，并且和电脑交互命令行壳层提供一个命令行界面（CLI）；而图形壳层提供一个图形用户界面（GULI）
Linux shell -> CLI Command-Line Interface
bash shell 最常见
zsh MacOS -> Unix 专业人选择

GUI：
1.X Windows
2.KDE
3.GNOME
4.Unity

ll 列出详细信息
ls -r 逆序
ls -m 横向输出
ls -alF 
exit 退出
~ 当前所在目录
$ 等待用户输入
man ls 显示有关ls的命令
白色是文件，蓝色是文件夹
Linux一切皆文件
\ 反斜线 windows
/ 正斜线 linux
cd / 根目录
```



### 文件系统

```
/etc 系统配置文件目录
/bin 命令目录
/home 主目录，显示所有用户
/lib 库目录（依赖）
/lost + found 断电丢失文件
/mnt 挂载目录
/proc 伪文件系统
/run 运行目录（临时）
/tmp 临时目录
/var 可变目录(log)
/boot 启动目录
/dev 设备目录
/media 媒体目录
/opt 可选目录
/root 管理员
/sbin 系统二进制目录，GUN高级管理员使用的命令工具
/srv 服务目录 本地目录
/usr 用户二进制目录，GNU工具
```

### cd命令

```
cd ~ 回到 home/qinheart
cd / 回到 /
```

### ctrl命令

```
ctrl c 强制退出
ctrl shift c/v 强制复制/粘贴
ctrl + 左右方向键 --> 快速移动光标
ctrl + l 清空页面
ctrl + u 清空当前命令行
ctrl + u/k 删除前面/后面所有命令
```

### 通配符、元字符、转义符

```
ls -l fhs-2.3_*.pdf
	fhs-2.3_copy_1.pdf
ls -l fhs-2.3_copy?.pdf
	fhs-2.3_copy2.pdf

*代表多个符号，？代表一个符号
```

```
ls -l f[a-z]ck.txt
	fack.txt fuck.txt fzck.txt
ls -l f[!a-z]ck.txt
```

### 创建/复制/删除

```
touch 创建新文件/更新时间
mkdir 创建文件夹
	mkdir -p js/src/kign
cp 你想复制的文件 你想复制到哪
	cp -i 1.txt 2.txt 覆盖既有文件之前线询问用户
rm -ri king/
```

```
cp -r /home/qinheart/Documents/doc /home/qinheart/Downloads/
复制 doc 及其下面所有文件到 Downloads

cp /home/qinheart/Documents/doc/* /home/qinheart/Downloads/
复制 doc 下所有文件到 Dowmloads
```



### ls

```
-A 同 -a ，但不列出 "." (目前目录) 及 ".." (父目录)
-F 在列出的文件名称后加一符号；例如可执行档则加 "*", 目录则加 "/"
-R 若目录下有文件，则以下之文件亦皆依序列出
-a 显示所有文件及目录 (. 开头的隐藏文件也会列出)
-l 除文件名称外，亦将文件型态、权限、拥有者、文件大小等资讯详细列出
-r 将文件以相反次序显示(原定依英文字母次序)
-t 将文件依建立时间之先后次序列出
-s (size) 以1024字节的块为单位
-m 横向输出

du -sh * | sort -h # 按文件大小排序
qinheart@ubuntu-server:~$ ls -sh
total 12K
4.0K desktop  4.0K document  4.0K download
```

```
ls -AF
	列出目前工作目录下所有文件及目录；目录于名称后加 "/", 可执行档于名称后加 "*" :
ls -lR /king
	将 /king 目录以下所有目录及文件详细资料列出 :
推荐组合 --> ls -lFR 列出每个文件夹内容
			ls -lAF
```

### ink链接文件

1.符号链接（软链接）——快捷方式

​	原来的文件、文件夹必须是存在的

2.硬链接（只能在同一个介质里）

​	副本

```
ln -s 1.txt 1_linkfile
(硬链接不需要 -s )
ls -l
```

### mv

```
重命名 mv 1.txt 2.txt
移动 mv 2.txt ~/king/

恢复上一条命令的路径 cd !$
```

### 文件类型

```
查看文件类型 file 1.txt
		   file project/
```

### cat/more/less

```
cat -m 显示行号
more 每次显示一行
	b 上一页
	space 下一页
	q 退出
	
less
	pageup
	pagedn
tail -n 行数 demo.c 显示结尾数行
head
```

### 任务管理器

```
top
ps --> process status
	ps -A
	ps -l
	ps -f
ps -axu | grep named
kill 
```

### 磁盘挂载

```
磁盘情况
df -h
挂载U盘
sudo fdisk -l
sudo mount /dev/sdc1 /mnt
拔出U盘
sudo umount /dev/sdc1
```

### 排序

```
sort -n 按照文件大小排序
sort -M 按月份排序
sort -r 倒序排列

du -sh *
du -sh * | sort -nr
```

### 搜索

```
grep 搜索内容 路径
```

### 压缩、打包

```
tar gz
将一堆文件打包成一个文件，再压缩

tar -zcvf 文件名.tar.gz 要打包的文件
例： tar -zcvf demo.tar.gz ./Java
tar -zxvf 解压缩文件 
```

### 父子shell

```
bash
ps --forest
查看是否创建子shell执行
echo $BASH_SUBSEHLL
```

```
休眠 sleep 秒
	sleep 10& (后台运行)
```

```
jobs -l  查看pid
```

```
coproc frank_av { sleep 10; } &
挂在子 shell 后台
```

### 别名

```
alias li='ls -li'
可以使用 li 代替 ls -li 
```

### 变量

```
printenv --> environment 查看环境变量
echo $HOME --> 代替全局变量

用户变量
fuck='king'
	echo king
	全局变量
export fuck='king'
	echo $fuck
删除
unset fuck

添加系统变量
	PATH=$PATH:/home/frank.project/
	echo $PATH
	
显示出系统变量
	~/.bashrc
	~/.bash_bash_profile
	~/.profile
	~/.bash_login
```

### 软件

```
packge manage system --> PMS
包管理系统

dpkg Debain

apt-get
apt-cache
aptitude --> 解决工具依赖问题，但无人维护
apt --> 流行
apt -h
apt list 查看更新
```

```
GitHub 开源项目 The Fuck
```

### 用户与权限

```
系统账户 <500
sudo useradd t2 (为t2用户添加权限)
	sudo userdel t2
	
grop 组
小组目的：共享资源的权限
usermod

sudo groupadd group_name 创建组
sudo groupdel group_name 删除组
```

### 管理员权限

```
命令：su
敲完命令后让你输入密码，密码正确就能进root用户。 
======================================================
如果装系统时没让输入root密码，可以什么都不输入试试，或者试一下你创建用户时输入的密码。不行的话试着看能不能设置root密码，命令如下：
$:sudo passwd root
$:(输入密码)
$:（确认密码）

su 切换管理员权限
su qinheart 恢复普通用户权限
```

### 文件和文件夹权限

```
第一列（1个）
	d 文件夹
	- 文件
	l 链接文件
	b 可随机存取装置
	c 设备接口
第二列（3个）
	r 可读
	w 可写
	x 可执行
	
三组：
创始人权限、组成员权限、洽谈人权限
gedit 路径 --> 打开文件
```

### linux chmod

```
chmod --> change mode
文件调用权限：文件所有者(User)、用户组(Group)、其他用户(Other Users)
a表示所有用户
rwx --> 421
chmod abc file(a、b、c各为一个字母)
```

### vim

```
emacs 神之编辑器
vim 编辑器之神
```

```
普通模式（命令操作模式）：操作文件
插入模式
命令模式
可视化模式

H 左
L 右
J 下
K 上

ctrl B 上一页 ctrl Y
ctrl F 下一页 ctrl E

Shift G 最后一行
GG 第一行
O 跨越到下一行输入
X 删除光标所在字符
DD 删除一行
U 撤销
DW 移除光标所在单词
B 跳跃单词首字母
E 条约单词末尾
W 跳跃单词

可以配合 shift 大跳

shift + 6 跳跃到行首
shift +4 跳到末尾
r 替换当前字符
普通模式中，千万不要使用 Backspace、Delete
{}

y 复制
p 粘贴
yw 复制一个单词
y$ 复制到行末尾
v 可视化模式（选择文本）
V 按行选择
o 跳到开头
0 补全单词 
gg V G d

ctrl v 矩阵选择
vaw 快速选择单词
vab 包含小括号
vaB 包含大括号
shift < >  缩进
shift ~ 大小写切换
U 全部转化为大写
u 全部转化为小写

:s/要替换的/替换为/g(一行全部替换)
:%s/要替换的/替换为/g(全局替换)
:set number 临时显示行号
:开始行,结束行s/要替换的/替换为/g 全局替换
:%s/要替换的/替换为/gc 全局替换带提示
```

### 配置vim

```
touch /.vimrc
vim .vimrc
source .vimrc 配置当前终端
set syn=on 高亮
set tabstop=4
set softtabstop=4 缩进
set number 行数
set enc=utf-8 编码
set showmatch 括号匹配

set synts=on
set tabstop=4
set number
set softtabstop=4
set enc=utf-8
set showmatch
```

```
行数+gg 行号跳跃
vim . 打开文件（j k 选择）
```

### server

```
配置阿里云镜像源
http://mirrors.aliyun.com/ubuntu/
```

### Fedora

##### 升级Fedora33后，屏幕分辨率无法随着VMware窗口大小的改变而改变，设置里面也没有1920x1080分辨率的选项

复制并修改配置文件：

sudo cp /etc/vmware-tools/tools.conf.example /etc/vmware-tools/tools.conf
sudo vim /etc/vmware-tools/tools.conf

```
[resolutionKMS]
 
# Default is true if tools finds an xf86-video-vmware driver with
# version >= 13.2.0. If you don't have X installed, set this to true manually.
# This only affects tools for Linux.
#enable=true
```

将enable前的#去掉，然后执行：
sudo systemctl restart vmtoolsd.service