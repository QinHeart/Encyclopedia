官网下载稳定版镜像：https://openwrt.org/

用 Starwind转换格式 https://www.starwindsoftware.com/starwind-v2v-converter

### 如何生成`.config`

`.config`文件的作用就是定制编译过程中需要做的配置 如:

- 系统的配置
- 需要预装的软件包

它的生成方式有如下几种

### 方法一(拿来主义)

直接使用别人配置好的，如下是别的大神挑选的常用预装软件生成的配置，下载下来即可使用

https://raw.githubusercontent.com/esirplayground/AutoBuild-OpenWrt/master/x86_64.config

### 方法二(自己动手)

直接在`.github/workflows/build-openwrt.yml`开启ssh登录，然后ssh到服务端执行`make menuconfig`进行定制

### 方法三(自娱自乐)

这个方法其实是方法二的变形，只是所有的东西都要你自己来，自己搭建编译环境生成`.config`，

首先参考[链接](https://github.com/coolsnowwolf/lede)搭建本地编译环境,然后执行

```
$ make menuconfig
```

选择要安装的软件包和定制的配置项

```
$ ./scripts/diffconfig.sh > diffconfig # write the changes to diffconfig
$ cp diffconfig .config   # write changes to .config
$ make defconfig   # expand to full config
```



- 在`Run Workflow`时把`SSH connection to Actions`的值改为`true`（或者也可以不修改，而是通过 [webhook 方式](https://p3terx.com/archives/github-actions-manual-trigger.html#toc_2)发送带有`ssh`触发关键词的请求。）
- 在触发工作流程后，在 Actions 日志页面等待执行到`SSH connection to Actions`步骤，会出现类似下面的信息：

```none
To connect to this session copy-n-paste the following into a terminal or browser:

ssh Y26QeagDtsPXp2mT6me5cnMRd@nyc1.tmate.io

https://tmate.io/t/Y26QeagDtsPXp2mT6me5cnMRd
```

- 复制 SSH 连接命令粘贴到终端内执行，或者复制链接在浏览器中打开使用网页终端。（网页终端可能会遇到黑屏的情况，按 `Ctrl`+`C` 即可）
- cd openwrt && make menuconfig
- 完成后按`Ctrl`+`D`组合键或执行`exit`命令退出，后续编译工作将自动进行。

> **TIPS:** 固件目录下有个`config.seed`或者`config.buildinfo`文件，如果你需要再次编译可以使用它。