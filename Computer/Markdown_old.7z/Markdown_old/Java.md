# Java与生活

## 经典语录

- 语言只是实现目标的工具，而不是目标本身
- 万维网的关键是浏览器吧超文本页面转换到屏幕上
- 程序设计语言的成功取决于其支撑系统的能力而不是语法的精巧性。这就是为什么有明显缺陷的语言（C++/Visual Basic）可以大行其道
- Java的成功缘于其库类能够让人们轻松的完成原本有一定难度的事情
- Java中的函数叫方法

## 快捷键

```
Alt + Ins 创建文件
Alt + 1 --> 打开/关闭侧边栏
Ctrl + Alt + L 对齐
Ctrl + Alt + V 补全
sout 自动生成 --> System.out.printl
psvm --> public static void main(String[] args)
```

## 一带而过

### 注释

``` 
Ctrl + / --> 单行注释
/**/ 多行注释
/** 方法注释 --> @author/@since/@version
	在文件所在路径 javadoc Test.java
```



## Java程序设计概述

exe --> windows特有

class --> （字节码）文件、跨平台

### 常见误解

1. Java将成为所有平台的通用性语言，但某些领域，其他语言有更出色的表现

   IOS --> Objective C

   浏览器 --> javascript

   服务端、跨平台客户端 --> Java

2. Java对关键的应用程序反应速度慢

   java --> 服务端、跨平台客户端

   java applet --> 一种在浏览器中运行的Java程序

Android是Java的衍生产物

### Java程序设计环境

Java development kit 			java开发工具包  jdk

Java Runtime Environment  java运行环境  jre

Java Virtual Machine  		java虚拟机  jvm

#### Jdk安装方法

##### 1.新建系统变量：JAVA_HOME

> 路径取jdk路径
>
> ```
> **E:\xxx\jdk1.8**
> ```

##### 2.在系统变量 Path 后面追加

```
%JAVA_HOME%\bin
```

##### 3. 添加 CLASSPATH

```
.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar
```

##### 4. 验证

```
C:\Users\QinHeart>javac --version
javac 9.0.4
```

## Java基本程序设计结构

输出 Hello World

```
package com.QinHeart.demo;

public class Test {
    public static void main(String[] args){
        System.out.println("Hello World");
    }
}

public class Test
公共的   类    类名
public    static   void  main （String【】 args）
访问修饰符  关键字  返回类型 方法名  string类   字符串数组
```

运行

```
javac Test.java --> 生成class文件
java Test
```

### 字符串

```
String str_1 = "Hello World";
System.out.println(str_1.length()); //获取字符串个数
```

### 数组
```
1.初始化
	dataType[] arrayRefVar = {value0, value1, ..., value};
2.分配方式
	dataType[] arrayRefVar = new dataType[arraySize];
	arr[0] = 1;
	System.out.println("arr[0] = " + arr[0]);

for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
System.out.println("arr.length = "+ arr.length);
```

```排序
-->排序

int[] arr = {8,2,9,4,5};
Arrays.sort(arr);
for (int i : arr) {
	System.out.println(i);
        }
```

```java
复制

// 假设一个数组中保留了 5 个成绩，现在需要在一个新的数组中保存这五个成绩，同时留三个空余的元素供后期开发使用
int[] num_1 = new int[] {50,60,70,80,90};
System.out.println("原数组为：" + Arrays.toString(num_1));

int[] num_2 = ((int[]) Arrays.copyOf(num_1,8));
System.out.println("修改后数组为：");

for (int i = 0; i < num_2.length; i++) {
    System.out.printf(num_2[i] + "\t");
}
```

```java
假设有一个名称为 scores 的数组其元素为 8 个，现在需要定义一个名称为 newScores 的新数组。新数组的元素为 scores 数组的前 5 个元素，并且顺序不变。

int[] scores = new int[] {30,40,50,60,70,80,90,100};
System.out.println("score 数组中元素个数为 " + scores.length);
System.out.println("score 数组：" + Arrays.toString(scores));
int[] newScores = ((int[]) Arrays.copyOfRange( scores,0,5));
System.out.println("newScores 数组：" + Arrays.toString(newScores));
```

### 循环

```
for(dataType variable :arrayRefavr){
	System.out.println()
}
--> 打印数组所有元素
```

```
二分查找法 -->
int result_index = Arrays.binarySearch(arr,8);
System.out.println("result_index = " + result_index);
```

```
判断两个数组是否完全相等 -->
int[] arr_1 = {8, 2, 9, 4, 5};
int[] arr_2 = {8, 2, 9, 4, 5};
boolean equals = Arrays.equals(arr_1, arr_2);
System.out.println("equals = " + equals);
```

### 函数 --> 方法

```
简易函数 -->
    public static void main(String[] args){
        int sum = sum(2, 3);
        System.out.println("sum = " + sum);
    }
    public static int sum(int x,int y){
        return x + y ;
    }
    
    
1.创建函数
2.调用函数
```

方法的重载：方法名相同，参数个数或参数类型不同

```
public static void main(String[] args) {
        int sum_1 = sum(1, 2);
        System.out.println("sum = " + sum_1);
        double sum_2 = sum(1.1,3.3);
        System.out.println("sum_2 = " + sum_2);
        int sum_3 = sum(1,2,3);
        System.out.println("sum_3 = " + sum_3);
    }
    public static int sum(int x,int y){
        return x + y;
    }
    public static double sum(double x ,double y){
        return x + y;
    }
    public static int sum(int x,int y,int z){
        return x + y + z;
    }
```



## OOP 上半部分

- POP --> 面向过程：
  			过程：你想去做什么的时候，然后去做什么
    			缺点：目标不明确，不适用于大众

- OOP --> 面向对象：
  			不强调过程，只强调目标	
    			制定计划、目标 --> 执行完计划后达到目标
    			优点：站在更高的层面看待事物

  ​			计划，规划，设计 --> 大众化



设计思维：先考虑共性

对象 -->实例      对象 > 实例

实例:用生活中的一个东西，代替抽象的东西；是一个活生生的事物，是唯一的

​	实实在在的例子



类当中的变量和方法都总称为属性（共性，特性）

变量 --> 成员（他们组成和构成了类，是类的主要组成部分）

一个动作

this指调用对象



public 公共的，公有的——用户可以为所欲为

--> private



```
LocalDate

LocalDate newYearEve = LocalDate.now();
int year = newYearEve.getYear();
int month = newYearEve.getMonthValue();
int day = newYearEve.getDayOfMonth();
  System.out.printf("今天是 %d 年 %d 月 %d 日",year,month,day);
```



























### getter setter

```
public class RetireTest {
    
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
```

```
public static void main(String[] args) {
    
    RetireTest kong = new RetireTest();

    kong.setName("king");
    kong.setAge(22);

    System.out.println(kong.getName() + " " + kong.getAge());
}
```

### 构造方法

初始化对象

#### 垃圾回收机制

```
System.gc();
```





























## 基本程序设计结构

public 访问修饰符

关键字 class 后加 类名

类名使用“骆驼命名法”，如 KingTest

### 数据类型

#### 整型，浮点型

为避免混淆，长整型数值后面加 L ；float 类型数组后面加 F

#### char

只可容纳单个字符的一种基本数据类型，但强烈建议不要在程序中使用 char 类型

#### boolean --> true / false

### 变量与常量

#### 变量

逐一声明变量可以提高程序的可读性

变量指必须初始化

#### 常量

用关键字 final 定义

关键字 final 定义的变量只能被赋予一次

关键字 static final 定义类常量，定义在 main 方法外部

```
public class KingTest {
    public static final int NIM_1 = 100;
    public static void main(String[] args) {
        final int NUM_2 = 10 ;
        System.out.println("NUM_1 = " + NUM_1);
        System.out.println("NUM_2 = " + NUM_2);
    }
}
```

### 运算符

整数被0除会产生一个异常；浮点数被0 除会得到 无穷大 或 NAN

#### 数学函数与常量

Math：sqrt/pow/sin/cos/tan/atan/atan2/wxp/log/log10/PI/E

#### 数值类型转换

![](D:\QinHeart\Md\整数类型之间的合法转换.png)

实心箭头表示无信息丢失的转换；空心箭头表示有精度丢失的转换

```
int n = 123456789;
float m = n;
```

##### 强制类型转换

（目标类型）+ 变量名

```
double x = 9.997;
int num =(int) x;
```

```
四舍五入
double x = 9.997;
int num =(int) Math.round(x);
```

#### 字符串 String

##### 子串 substring

```
String str = "original";
String strTest = str.substring(0,3);
```

##### 拼接 +

##### 不可变字符串

优点:编译器可以让字符串共享

注: substring 与 + 得到的字符串不共享

##### 检测字符串是否相等 equals

```
String str = "original";
String num = "king";
if (str.equals(num)){
    System.out.println("success");
}else{
    System.out.println("default");
}
```

##### 空串与 null 串

空串 “ ” 是长度为 0 的字符串

检测字符串是否为空串：

```
if(str.length() == 0)
if(str.equals(""))
```

检测字符串是否为 null

```
if(str != null)
```

检测字符串既不是 空串 ，也不是 null

```
if(str != null && str.length != 0)
```

空串是一个 java 对象，有自己的串长度（0）和内容（空）

String 变量可以存放一个特殊地方值( null )，表示目前没有任何对象与该变量关联

##### 码点与代码单元

char 类型容易出错，尽量不要使用

##### 构建字符串

避免每次创建字符串都会产生一个新的 String 对象

#### 输入与输出

标准输入流 --> System.in

```
// 输入与输出
Scanner in = new Scanner(System.in);

// first input
System.out.println("what's you name?");
String name = in.nextLine();

// second input
System.out.println("How old are you?");
int age = in.nextInt();

// display output on console
System.out.println("Hello" + " " + name + " " + "." + "You are" + " " + age + " " + "years old.tom");
```

##### 格式化输出

```
%f 浮点数
%s 字符串
%d 十进制
%x 十六进制
%o 八进制
```

```
double dun = 10000.0/3.0;
System.out.printf("dun_1 = %f\n", dun);
System.out.printf("dun_1 = %.3f", dun);
```

有关时间（ new Date() ）的输出详见 JAVA核心技术 卷一 P59

##### 文件输入与输出

略

#### 流程控制

else 语句与最领进的 if 构成一组

##### 循环

```
if
while
do while 至少循环一次
for
	不同的 for 循环中可以使用相同的变量
```

### 对象与类

#### JAVA库类中的 LocalDate 类

```
LocalDate Date = LocalDate.now();
int month = Date.getMonthValue();
int day = Date.getDayOfMonth();
System.out.printf("Today is %d month %d day",month,day);
```